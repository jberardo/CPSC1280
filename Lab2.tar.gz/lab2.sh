#!/bin/sh

# print user name on console
echo $USER

# print current dir
echo `pwd`

# print contens of files starting with 'l' and ending with 'h'
echo `ls -la l*h`
